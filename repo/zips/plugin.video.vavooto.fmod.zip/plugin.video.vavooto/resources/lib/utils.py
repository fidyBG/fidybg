# -*- coding: utf-8 -*-
import xbmcgui, xbmcaddon, sys, xbmc, os, time, json
PY2 = sys.version_info[0] == 2
if PY2:
	from urlparse import urlparse, parse_qsl
	from urllib import urlencode
	translatePath = xbmc.translatePath
else:
	from urllib.parse import urlencode, urlparse, parse_qsl
	import xbmcvfs
	translatePath = xbmcvfs.translatePath

def py2dec(msg):
	if PY2:
		return msg.decode("utf-8")
	return msg

def py2enc(msg):
	if PY2:
		return msg.encode("utf-8")
	return msg

addon = xbmcaddon.Addon()
addonInfo = addon.getAddonInfo
addonID = addonInfo('id')
addonprofile = py2dec(translatePath(addonInfo('profile')))
addonpath = py2dec(translatePath(addonInfo('path')))
if not os.path.exists(addonprofile):
	os.makedirs(addonprofile)

favoritenfile = os.path.join(addonprofile,"tvfavoriten")

def selectDialog(list, heading=None, multiselect = False):
	if heading == 'default' or heading is None: heading = addonInfo('name')
	if multiselect:
		return xbmcgui.Dialog().multiselect(str(heading), list)
	return xbmcgui.Dialog().select(str(heading), list)

home = xbmcgui.Window(10000)

def set_cache(key, value, timeout=300):
	data={"sigValidUntil": int(time.time()) +timeout,"value": value}
	home.setProperty(key, json.dumps(data))
	
def get_cache(key):
	keyfile = home.getProperty(key)
	if keyfile:
		r = json.loads(keyfile)
		if r.get('sigValidUntil', 0) > int(time.time()):
			return r.get('value')
		home.clearProperty(key)
	return

def getAuthSignature():
	signfile = get_cache('signfile')
	if signfile: return signfile
	vec = {"vec": "zXejWtWwSnudkwqoq9jWbXHWeRpYhGfOdp0DTMUFnDMDXULbFhvBB03sq98lFf8aXfmI7jGg0fwkkcw2G1h/yr4MucyGu5bWVxci4LHy4GhX/T0vMt05fwPZxeeZ+a0rqcd8Dw4nkmDvig3hEJdBptrNxKgvGXX7A8gEpfrOMUb5WLJp7ODEkHaDa/EIxw1fBZFTETGA3msOKWu+OZNKTJeI6lkEYiX1jfHDFHphGksGcWp1NaBr74DiZZjPVXAbUIgD4IaSkBEhiWnOI1dmH8JdsMsd92xyfnZGZma4Kx2hu9iiKmcaPaVBtgDR7h0hfSkhCAZ27OZXbXbBN+l6MfuQU6ZQsMbcIJK66y/sgJZQ6031sLoDj5I8LA4S+oAh77moMslXg72tTaPHBY1CuqUnlk1dta3K4VIeD/rzmKFIPi8hxtxLGGQudU5+SgBvMUpGUIL1WS8Jap3noA+mtT069ANTZKAsP3xLb9PLh9r3cUrT7NSy6nG12UYam0sBXaA74lcoNyQQJOPQ3fx6P/PIRDn1bEBHwXhm+W1yNJ7Ku5LlKIuyauT6G6RK3xjmGvSiZRiQZpeM1n5lY7eqYAyt0cJlVaPm+4kaaXkS5IDrKHeM1QLekt5ioVPwJVIK1kYmHYvEdpAtpbHWpzOviDEK7FYHiN726fVMZvxSoqxKOQ2Jh7Z0pIMFiQkG21dTHJkEJl8c8sD5on69PeKe9NutV3RQ/LLg1dPy4dyClSTTgYm4DE+9l7ywnI/qisczQs0Yl0KXUGdm0FwEkS1flslTCncbbye7UDqefSUSvVB64e5IXxtEEW8yGJXHcbPmIuV+gNukkBKU5C7FAmXes3NND/3S0fooMmoH/NPI+9CbImUMLlZR/pkP/uHUU20z6/2L1TGYOJUeo2E/j8vbGCvpkKishMlqX7Xx4PL3dDGPAbAnxZuRZ1NHAC6gJcKfrWXZ4j63ZCNLFek4VQauS1rVgH3vnss/0c52FZ0RkR3j6AuselqY+BjzN4/bHTRKaZX/USiLy3rAUtXl2z77oRR0PMCoNH6Jd5otKEsWul8U4qyRzOSWFiYSTo3qQXi4Yz8yg4Kp1NcRBaKwWvxqX7ySnlVFsHH/LmVo23JcpRzaCA4bBhjumF9PKe9dle42N5QsqE3lEtNQ/BjHH3YpgbFmr5MbSVNeEtAoiCM90pg7mxMNPjHGB98jBxl2N4Pj7puDjZczPYYVhDE84KfXPPtSDhQDXh0vv9k2Uzhgk0nSIUgrUIptejgf//05B2aT81gUhHOtlFCwVEa2eHukDuk7WvqvJ5yDiGMKKorcSzoD2KpgpIelwYy/4WhIXoB94tKB9tnafejH+bgovej5lFh1FgppBfMS+ue0SuqQqTSmduO2G1owkBIsx6ljByNsx9KVwn6OE/O5TGKFExgJD3TJDQEbYuTiWKefLMlILURLo9ddAIudB96I7w/anCS5xeNkfuDfEJ26PKGFXdnS9DJgPWSq4FXyF3ctwAAy6RKcoprdbadB09gCCYni28zmccu9Fv7iZfDyzC9Rehylx1ZdXWdJK8GODi2LPO0c2yx9MWElz9Sz7fCnAzaMV7pUP2JPDHLDAIk2oFw6iEA93pwL05GBtKR9V1zala2VatOf6zO4bf0b9nq/yQ3RHtgYs3RZcL4f8xXvtVTPW9iAes8m2ra9A2zL2g49o9TpmKw9R9Fj43VaRaRpa9L29tLoeLjMP+ZpbwVBJkR1nOecj4yaOW3a8sUkMT0T2WDA0LzEexkcjxEnjYoWRUNkiMODskzEQWTfrZygqNM/GP6tRGCi+4pQmCpeQh8xjGMryymZ5+aDQS3OY+oDz3CTSL0WRrnF0SbPIf0aqlQQx6Z7d5bjujz1ysIkErelYJj+DCkWV/XnSPyX8I4PQSWjWzH6NP236sJDZrp4os3WAQQRU9kpzbpSXGZsWuuL8UOZJlvl3wfcoh7FtsJKrj3aQUftZf6LF0cjtWENO0ZOSMviFefVkhxa5g4YCBBzfoXpW0abEKtG9K6HCU5CiKj084+zFh8OadKJEhwmAwQwMt2KVSfFnMIhdLyVxre+uP80h5E1WR6pdY3SiHFsSP28FpWFqXgxkTPpK8BB19hQ8Wu3gS4KhoIq2aEtXUaKiGqfDIdexZIA1sCPCPXI1utSs1WFTWUM1Jb+Md6F0wYGZ9sa2t782933mAXH1lV4Kx6rydk="}
	url = 'https://www.vavoo.tv/api/box/ping2'
	import requests
	req = requests.post(url, data=vec).json()
	signed = req['response'].get('signed')
	set_cache('signfile', signed)
	return signed

def log(*args):
	msg=""
	for arg in args:
		msg += repr(arg)
	xbmc.log(msg, xbmc.LOGINFO)

def yesno(heading, line1, line2='', line3='', nolabel='', yeslabel=''):
	if PY2: return xbmcgui.Dialog().yesno(heading, line1,line2,line3, nolabel, yeslabel)
	else: return xbmcgui.Dialog().yesno(heading, line1+"\n"+line2+"\n"+line3, nolabel, yeslabel)
	
def ok(heading, line1, line2='', line3=''):
	if PY2: return xbmcgui.Dialog().ok(heading, line1,line2,line3)
	else: return xbmcgui.Dialog().ok(heading, line1+"\n"+line2+"\n"+line3)

def getIcon(name):
	return "%s/resources/art/%s.png" % (addonpath ,name)

def getPluginUrl(params):
	return "%s?%s" % (sys.argv[0], urlencode(params))
	
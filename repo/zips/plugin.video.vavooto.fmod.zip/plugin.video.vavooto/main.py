# -*- coding: utf-8 -*-
if __name__ == '__main__':
	from resources.lib import vjackson
	vjackson.main()